#include "buttoneventhandler.h"

ButtonEventHandler::ButtonEventHandler()
{
    serial = new QSerialPort(this);
    this->init_serial();
}

void ButtonEventHandler::CloseConn()
{
    serial->close();
}

void ButtonEventHandler::init_serial()
{
    serial->setPortName(button_serial_port);
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);
}
