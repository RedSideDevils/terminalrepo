#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QCoreApplication>
#include <QTime>
#include <QHostAddress>
#include <QMessageBox>
#include <QSettings>
#include <QSerialPort>
#include <QFileSystemWatcher>
#include <QFile>
#include <QBuffer>
#include <QIODevice>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

//Error Defines
#define IP_CHANGED 1
#define IP_CHANGE_ERROR 0

//Page Indexes
#define HOMEPAGE 0
#define CONFIGPAGE 1
#define USERNOTFOUNDPAGE 2
#define WELCOMEPAGE 3
#define ONETIMETICKPAGE 5

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    int RedirectDelayTime;

    QHostAddress DeviceIp;
    QHostAddress ServerIp;
    QHostAddress tempIp;

    QString MAGICNUM;
    QString ConfigFileName;
    QSettings *config;

    QSerialPort *serial;
    QString button_serial_port;

    QFileSystemWatcher * NFCwatcher;
    QFileSystemWatcher * QRwatcher;

    QString NFCPath;
    QString QRPath;

    QString NFCFileName;
    QString QRFileName;

private slots:
    int SetIp(QHostAddress *ip, QString newIp);
    void serialRecieved();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_5_clicked();
    void on_ExitBTN_clicked();

//Methods
private:
    void InitSerial();

public slots:
    void LoadConfig();
    void SaveConfig();
    void ChangeText(QString text);
    void ChangePage(int page);
    void Delay(int seconds);

    void NFChandle(QString str);
    void QRhandle(QString str);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
