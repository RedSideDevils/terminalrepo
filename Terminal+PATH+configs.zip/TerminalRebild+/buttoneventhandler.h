#ifndef BUTTONEVENTHANDLER_H
#define BUTTONEVENTHANDLER_H

#include <QObject>
#include <QSerialPort>

class ButtonEventHandler
{
    Q_OBJECT

public:
    QString button_serial_port;

private:
    QSerialPort *serial;

public:
    ButtonEventHandler();

public:
    void CloseConn();

private:
    void init_serial();

};

#endif // BUTTONEVENTHANDLER_H
