from keyboard_alike import reader
import threading
import os 
from mylib import NFCCodeReader, QrCodeReader
from utilities import ModifyTempFile

def QRThread():
    QrReader = QrCodeReader(0xe851, 0x2100, 64, 8, should_reset=True)
    QrReader.initialize()

    while True:
        data = QrReader.read().strip()
        if data is not None:
            print("[QR RECIEVED]: {}".format(data))
            if(ModifyTempFile("QrTempFile", data) > 0): print("[QR SAVED]")


def NFCTread():
    NfcReader = NFCCodeReader(0xffff, 0x0035, 64, 8, should_reset=True)
    NfcReader.initialize()

    while True:
        data = NfcReader.read().strip()

        if data is not None:
            print("[NFC RECIEVED]: {}".format(data))
            if(ModifyTempFile("NfcTempFile", data) > 0): print("[NFC SAVED]")

if __name__ == "__main__":
    t1 = threading.Thread(target=QRThread, name='t1')
    t2 = threading.Thread(target=NFCTread, name='t2')

    t1.start()
    t2.start()

    t1.join()
    t2.join()