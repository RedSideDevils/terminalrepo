from escpos.printer import Usb
import usb.core
import usb.util
import usb.backend.libusb1

#remember to change pid and vid with your own values!
p = Usb(0x1051, 0x1000, 0, 0x81, 0x02)

# p.set(
#         underline=0,
#         align="center",
#         font="a",
#         width=4,
#         height=4,
#         density=2,
#         invert=0,
#         smooth=False,
#         flip=False,
# )

# p.text("\n\n")
# p.image("/home/user/Documents/Driver/frame.png",impl="bitImageColumn", center=True)
# p.text("\n\n")

# # p.qr("You can readme from your smartphone", size=12, native=True)


p.text("\n")
p.set(
        underline=0,
        align="center",
        font="a",
        width=2,
        height=2,
        density=2,
        invert=0,
        smooth=False,
        flip=False,       
    )
#Printing the image
p.image("/home/user/Documents/Driver/frame.png",impl="bitImageColumn")
#printing the initial data
p.textln("\n")

p.text("\x1b" + "\x69")

print("done")