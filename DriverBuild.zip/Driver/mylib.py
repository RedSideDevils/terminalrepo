from keyboard_alike import reader

class NFCCodeReader(reader.Reader):
    pass

class QrCodeReader(reader.Reader):
    pass