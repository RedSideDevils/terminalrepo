import os

def ModifyTempFile(filename, data):
    if type(data) != str:
        return 0
    
    try:
        file = open(filename, 'r+')
    except FileNotFoundError:
        file = open(filename, 'w+')
        
    tempData = file.read()
    
    if tempData is not None:
        file.truncate(0)

    file.seek(0, os.SEEK_SET)
    file.write(data)

    file.close()
    
    return len(data) 
