from keyboard_alike import reader
import threading
import os 
from mylib import NFCCodeReader, QrCodeReader
from utilities import ModifyTempFile
from escpos.printer import Usb

def PrinterThread():
    PrinterThreadState = "init"
    files = []
    folder_path = "temp"    
    printer = ""
    qr_file_name = "qr.png"
    
    while True:
        if PrinterThreadState == "init":
            try:
                printer = Usb(0x1051, 0x1000, 0, 0x81, 0x02)

            except:
                print("[ERROR]Printer Not Found! Check address to thermal printer.")
                #exit()
            
            else:
                print("[STATUS]Printer Initilization Done. Move to waiting mode.")
                PrinterThreadState = "handler"

        elif PrinterThreadState == "handler":
            try:
                files = os.listdir(folder_path)

            except FileNotFoundError:
                print("[ERROR] temp folder not found. Creating directory.")     
                os.mkdir(folder_path)                 
            
            else:
                if "qr.png" in files:
                    PrinterThreadState = "print"

        elif PrinterThreadState == "print":
            print("[STATUS]Printing QR.")
            printer.text("\n")
            printer.set(
                    underline=0,
                    align="center",
                    font="a",
                    width=2,
                    height=2,
                    density=2,
                    invert=0,
                    smooth=False,
                    flip=False,       
            )
            printer.image(folder_path + qr_file_name, impl="bitImageColumn")
            printer.textln("\n")
            printer.text("\x1b" + "\x69")        
            print("[STATUS]QR Printed.")            
            os.remove(folder_path + "/" + qr_file_name)                    
            PrinterThreadState = "handler"
            
                
def QRThread():
    QRThreadState     = "init"
    QRStrLen          = 6 
    
    file_path = "temp/QrTempFile"
    
    while True:
        if QRThreadState == "init":
            try:
                QrReader = QrCodeReader(0xe851, 0x2100, 64, 8, should_reset=True)
                QrReader.initialize()

            except:
                print("[ERROR]QR Device not found! Check address to USB device.")       
                #exit()

            else:
                print("[STATUS]RUNNING READER FOR QR")
                QRThreadState = "read"

        elif QRThreadState == "read":
            try:
                data = QrReader.read().strip()
            
            except:
                print("[ERROR]CONNECTION LOST WITH QR")
            
            finally:
                QRThreadState = "init"

            if len(data) == QRStrLen:
                print("[STATUS]QR RECIEVED")
                if(ModifyTempFile(file_path, data) > 0): print("[STATUS]QR SAVED")
                else: print("[ERROR]CANNOT SAVE QR DATA")
    
 
def NFCTread():
    NFCThreadState     = "init"
    NFCStrLen          = 6 

    file_path = "temp/NfcTempFile"
    
    while True:
        if NFCThreadState == "init":
            try:
                NfcReader = NFCCodeReader(0xffff, 0x0035, 64, 8, should_reset=True)
                NfcReader.initialize()

            except:
                print("[ERROR]NFC Device not found! Check address to USB device.")       
                #exit()
                
            else:
                print("[STATUS]QR READER FOUND")
                NFCThreadState = "read"

        elif NFCThreadState == "read":
            try:
                data = NfcReader.read().strip()
            
            except:
                print("[ERROR]CONNECTION LOST WITH NFC")
            
            finally:
                NFCThreadState = "init"

            if len(data) == NFCStrLen:
                print("[STATUS]NFC RECIEVED")
                if(ModifyTempFile(file_path, data) > 0): print("[STATUS]NFC SAVED")
                else: print("[ERROR]CANNOT SAVE NFC DATA")


if __name__ == "__main__":
    t1 = threading.Thread(target=QRThread, name='t1')
    t2 = threading.Thread(target=NFCTread, name='t2')
    t3 = threading.Thread(target=PrinterThread, name='t3')
    
    t1.start()
    t2.start()
    t3.start()
    
    t1.join()
    t2.join()
    t3.join()