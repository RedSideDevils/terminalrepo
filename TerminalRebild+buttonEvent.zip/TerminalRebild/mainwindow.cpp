#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    QMainWindow::showFullScreen();

    MAGICNUM = "59211";
    ConfigFileName = "config.ini";
    button_serial_port_flag = 0;
    time = 0;
    button_event_handle_timer = new QTimer(this);

    config = new QSettings(ConfigFileName, QSettings::IniFormat);
    serial = new QSerialPort(this);

    LoadConfig();
    InitSerial();
}

void MainWindow::ChangeText(QString text)
{
    ui -> StatusBar -> setText(text);
}

void MainWindow::Delay(int seconds)
{
    QTime dieTime= QTime::currentTime().addSecs(seconds);

    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void MainWindow::ChangePage(int page)
{
    ui -> stackedWidget -> setCurrentIndex(page);
}

int MainWindow::SetIp(QHostAddress *ip, QString newIp)
{
    tempIp.setAddress(newIp);

    if (QAbstractSocket::IPv4Protocol == tempIp.protocol())
    {
        ip->setAddress(newIp);
        return IP_CHANGED;
    }

    return IP_CHANGE_ERROR;
}

void MainWindow::LoadConfig()
{
    if(config->value("Params/magicnum") != MAGICNUM)
    {
        config->setValue("Params/magicnum", MAGICNUM);
        ChangePage(CONFIGPAGE);
        return;
    }

    if(SetIp(&DeviceIp, config->value("Params/device_ip").toString()) == IP_CHANGE_ERROR || SetIp(&ServerIp, config->value("Params/server_ip").toString()) == IP_CHANGE_ERROR)
    {
        ChangePage(CONFIGPAGE);
        return;
    }

    button_serial_port = config->value("Params/button_serial_port").toString();
    ChangePage(HOMEPAGE);
    connect(button_event_handle_timer, SIGNAL(timeout()), this, SLOT(button_event_handler()));
    button_event_handle_timer->start(1);
    ChangeText(DeviceIp.toString() + " | " + ServerIp.toString() + " | " + button_serial_port);
}

void MainWindow::SaveConfig()
{
    config->setValue("Params/device_ip", DeviceIp.toString());
    config->setValue("Params/server_ip", ServerIp.toString());
    config->setValue("Params/button_serial_port", button_serial_port);
}

void MainWindow::on_pushButton_5_clicked()
{
    if(SetIp(&DeviceIp, ui->device_ip->text()) == IP_CHANGE_ERROR || SetIp(&ServerIp, ui->server_ip->text()) == IP_CHANGE_ERROR || ui->button_serial_port->text().length() == 0)
    {
        QMessageBox::warning(this, "Warning!","Invalid Input!");
        return;
    }

    if(button_serial_port != ui->button_serial_port->text())
    {
        button_serial_port = ui->button_serial_port->text();
        InitSerial();
    }

    ChangeText(DeviceIp.toString() + " | " + ServerIp.toString() + " | " + button_serial_port);
    SaveConfig();

    QMessageBox::information(this, "Info","Configuration Done!");
    ChangePage(0);
}

void MainWindow::on_pushButton_clicked()
{
    QString Response = sendRequest(DeviceIp.toString(), "outer");
    if (Response == "ERROR") ChangePage(1);
    else ChangePage(2);
    Delay(2);
    ChangePage(0);
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->server_ip->setText(ServerIp.toString());
    ui->device_ip->setText(DeviceIp.toString());
    ui->button_serial_port->setText(button_serial_port);
    ChangePage(CONFIGPAGE);
}

void MainWindow::on_ExitBTN_clicked()
{
    qApp->exit();
}

void MainWindow::InitSerial()
{
    serial->setPortName(button_serial_port);
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);
    connect(serial, SIGNAL(readyRead()), this, SLOT(serialRecieved()));
}

void MainWindow::serialRecieved()
{
    button_serial_port_flag = 1;
    ChangePage(WELCOMEPAGE);
    Delay(2);
    ChangePage(HOMEPAGE);
    button_serial_port_flag = 0;
}

void MainWindow::button_event_handler()
{
    if(serial->isDataTerminalReady())
    {
        ChangePage(ONETIMETICKPAGE);
        Delay(2);
        ChangePage(HOMEPAGE);
    }
}

MainWindow::~MainWindow()
{
    serial->close();
    delete ui;
}

