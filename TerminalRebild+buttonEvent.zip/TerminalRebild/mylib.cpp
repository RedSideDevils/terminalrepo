#include "mylib.h"

QString sendRequest(QString myIp, QString Type)
{
    QString StrStatus;
    QString StrMessage;
    QEventLoop eventLoop;
    //Setting Up
    QNetworkAccessManager mgr;
    QObject::connect(&mgr, SIGNAL(finished(QNetworkReply*)), &eventLoop, SLOT(quit()));

    //HTTP Request
    QNetworkRequest req( QUrl( QString("https://system.smartparking.locator.am/api/get_loop_info?ip=%1&type=%2").arg(myIp).arg(Type)));
    QNetworkReply *reply = mgr.get(req);
    eventLoop.exec();

    if (reply->error() == QNetworkReply::NoError)
    {
        //success
        QByteArray buffer = reply->readAll();
        QJsonDocument jsonDoc(QJsonDocument::fromJson(buffer));
        QJsonObject jsonReply = jsonDoc.object();
        QJsonValue  status  = jsonReply.value("status");
        QJsonValue  message = jsonReply.value("message");

        if (status.isUndefined() || message.isUndefined())
        {
                return "ERROR";
        }

        StrStatus  = status.toString();
        StrMessage = message.toString();

        if(StrStatus != "0")
        {
            return "ERROR";
        }

        delete reply;
        //If all success return get Message
        return StrMessage;
    }
    else
    {
        //failure
        //qDebug() << "Failure" <<reply->errorString();
        delete reply;

        return "ERROR";
    }
}
