#ifndef WATCHER_H
#define WATCHER_H

#include <QMainWindow>
#include <QObject>
#include <QTextEdit>

class Watcher : public QTextEdit
{
    Q_OBJECT
public:
    Watcher(QWidget* pwgt = 0);

private slots:
    void slotDirectoryCh(QString&);
    void slotFileCh     (QString&);
};

#endif // WATCHER_H
