#ifndef GLOBAL_H
#define GLOBAL_H

//Page Indexes
#define HOMEPAGE            0
#define CONFIGPAGE          1
#define USERNOTFOUNDPAGE    2
#define WELCOMEPAGE         3
#define ONETIMETICKPAGE     4
#define ERROR_PAGE          5
#define NOT_FREE_SPACE_PAGE 6

//Errors
#define ERROR_CANNOT_CONNECT_SERVER 0
#define ERROR_NOT_REGISTERED_ID     1
#define ERROR_API_READ_GOES_WRONG   2
#define ERROR_SOMETHING_WENT_WRONG  3
#define ERROR_CANNOT_OPEN_TEMP_FILE 4

//Slots Defines
#define BUTTON_SLOT 0
#define QR_SLOT     1
#define NFC_SLOT    2

#endif // GLOBAL_H
