#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QCoreApplication>
#include <QTime>
#include <QHostAddress>
#include <QMessageBox>
#include <QSettings>
#include <QSerialPort>
#include <QFileSystemWatcher>
#include <QFile>
#include <QBuffer>
#include <QIODevice>
#include <QTcpSocket>
#include "QRWidget.hpp"
#include "client.h"
#include "global.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    int RedirectDelayTime;

    QString MAGICNUM;
    QString ConfigFileName;

    QString button_serial_port;

    QFileSystemWatcher * NFCwatcher;
    QFileSystemWatcher * QRwatcher;

    QString NFCPath;
    QString QRPath;
    QString generatedQRPath;

    QString DeviceId;

private:
    void initListener();

private slots:
    void slotCPSC();
    void on_pushButton_5_clicked();

//Methods
private:
    void LoadConfig();
    void SaveConfig();
    void ChangeText(QString text);
    void PageHandler(int page);
    void Delay(int seconds);
    void InitClient();
    void InitSerial();
    void InitCPSC();

public slots:
    void slotAllFine(QString str);
    void slotPrintQr(QString qr);
    void slotNotEmptySpace();
    void slotUserNotFound();
    void slotWelcome();
    void slotError(int ErrorId);
    void NFChandle(QString str);
    void QRhandle(QString str);

signals:
    void signalNewQR(QString qr);
    void signalNewNFC(QString nfc);

private:
    Ui::MainWindow *ui;
    client *myClient;
    QSettings *config;
    QSerialPort *serial;
    QAction *configSC;
    QAction *exitSC;
    QAction *returnSC;
};
#endif // MAINWINDOW_H
