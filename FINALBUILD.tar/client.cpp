#include "client.h"

client::client()
{
    btn_pressed_flag  = false;
    qr_recieved_flag  = false;
    nfc_recieved_flag = false;
}

int client::SetServerIp(QString newIp)
{
    tempIp.setAddress(newIp);

    if (QAbstractSocket::IPv4Protocol == tempIp.protocol())
    {
        serverIp.setAddress(newIp);
        return IP_CHANGED;
    }

    return IP_CHANGE_ERROR;
}

void client::sendButtonEvent()
{
    if(!btn_pressed_flag)
    {
        socket = new QTcpSocket(this);
        BTN_GET_REQUEST = QString("GET /api/get_btn_info?ip=%1&type=%2 HTTP/1.1\r\nHost: system.smartparking.locator.am\r\nConnection: close\r\n\r\n").arg(dId, "outer");
        if(!socket->isOpen()) socket->connectToHost(serverIp, port);

        Data = BTN_GET_REQUEST.toUtf8();

        if (socket->waitForConnected(CONNECT_TIMEOUT))
        {
            socket->write(Data);
            connect(socket, &QTcpSocket::readyRead, this, std::bind(&client::TcpData, this, BUTTON_SLOT));
            btn_pressed_flag = true;
        }
        else
        {
            emit signalError(ERROR_CANNOT_CONNECT_SERVER);
            return;
        }
    }
}

void client::sendQREvent(QString qr)
{
    if(!qr_recieved_flag)
    {
        socket = new QTcpSocket(this);
        if(!socket->isOpen()) socket->connectToHost(serverIp, port);

        QR_GET_REQUEST = QString("GET /api/get_btn_info?ip=%1&type=%2 HTTP/1.1\r\nHost: system.smartparking.locator.am\r\nConnection: close\r\n\r\n").arg(dId, qr);

        Data = QR_GET_REQUEST.toUtf8();

        if (socket->waitForConnected(CONNECT_TIMEOUT))
        {
            socket->write(Data);
            connect(socket, &QTcpSocket::readyRead, this, std::bind(&client::TcpData, this, QR_SLOT));
            qr_recieved_flag = true;
        }
        else
        {
            emit signalError(ERROR_CANNOT_CONNECT_SERVER);
            return;
        }
    }
}

void client::sendNFCEvent(QString nfc)
{
    if(!nfc_recieved_flag)
    {
        socket = new QTcpSocket(this);
        if(!socket->isOpen()) socket->connectToHost(serverIp, port);

        NFC_GET_REQUEST = QString("GET /api/get_btn_info?ip=%1&type=%2 HTTP/1.1\r\nHost: system.smartparking.locator.am\r\nConnection: close\r\n\r\n").arg(dId, nfc);

        Data = NFC_GET_REQUEST.toUtf8();

        if (socket->waitForConnected(CONNECT_TIMEOUT))
        {
            socket->write(Data);
            connect(socket, &QTcpSocket::readyRead, this, std::bind(&client::TcpData, this, NFC_SLOT));
            nfc_recieved_flag = true;
        }
        else
        {
            emit signalError(ERROR_CANNOT_CONNECT_SERVER);
            return;
        }
    }

}

void client::TcpData(int mode)
{
    disconnect(socket, SIGNAL(readyRead()), this, SLOT(TcpData(int)));
    QByteArray buffer = socket->readAll();
    QJsonDocument jsonDoc(QJsonDocument::fromJson(buffer));
    QJsonObject jsonReply = jsonDoc.object();
    QJsonValue status = jsonReply.value("status");
    QJsonValue message = jsonReply.value("message");

    switch (mode)
    {
        case BUTTON_SLOT:
            if(btn_pressed_flag)
            {
                if (status.toString() == "0")
                {
                    emit signalError(ERROR_NOT_REGISTERED_ID);
                }
                else if (status.toString() == "1")
                {
                    if (message.toString() != "User does not have parking space at his moment")
                        emit signalToPrintQr(message.toString());

                    else
                        emit signalNotEmptySpace();
                }
                btn_pressed_flag = false;
            }

            break;

        case QR_SLOT:
            if(qr_recieved_flag)
            {
                if(status.toString() == "0")
                {
                    emit signalError(ERROR_NOT_REGISTERED_ID);
                }
                else if(status.toString() == "1")
                {
                    if (message.toString() == "OK")
                        emit signalWelcome();

                    else if (message.toString() == "User not found")
                        emit signalUserNotFound();

                    else if (message.toString() == "User does not have parking space at his moment")
                        emit signalNotEmptySpace();

                    else
                        emit signalError(ERROR_API_READ_GOES_WRONG);
                }
                qr_recieved_flag = false;
            }

            break;

        case NFC_SLOT:
            if(nfc_recieved_flag)
            {
                if(status.toString() == "0")
                {
                    emit signalError(ERROR_NOT_REGISTERED_ID);
                }
                else if(status.toString() == "1")
                {
                    if (message.toString() == "OK")
                        emit signalWelcome();

                    else if (message.toString() == "User not found")
                        emit signalUserNotFound();

                    else if (message.toString() == "User does not have parking space at his moment")
                        emit signalNotEmptySpace();

                    else
                        emit signalError(ERROR_API_READ_GOES_WRONG);
                }
                nfc_recieved_flag = false;
            }
            break;

        default:
            emit signalError(ERROR_SOMETHING_WENT_WRONG);
            break;

    }

    if (socket->isOpen())
    {
        socket->close();
    }
}

int client::SetPort(QString newPort)
{
    for (int i = 0; i < newPort.size(); i++)
    {
        if (newPort[i].isLetter())
            return PORT_CHANGE_ERROR;
    }

    port = newPort.toInt();
    return PORT_CHANGED;
}

QString client::GetServerIp()
{
    return serverIp.toString();
}

QString client::GetPort()
{
    return QString("%1").arg(port);
}

void client::setDId(QString newId)
{
    dId = newId;
}

client::~client()
{
}
