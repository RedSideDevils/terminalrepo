#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QMainWindow::showFullScreen();

    MAGICNUM       = "59211";
    ConfigFileName = "config.ini";

    NFCwatcher = new QFileSystemWatcher(this);
    QRwatcher  = new QFileSystemWatcher(this);

    config   = new QSettings(ConfigFileName, QSettings::IniFormat);
    serial   = new QSerialPort(this);
    myClient = new client();

    configSC = new QAction(this);
    exitSC   = new QAction(this);
    returnSC = new QAction(this);

    InitCPSC();
    LoadConfig();
    InitSerial();
    InitClient();
//    ui->centralwidget->setStyleSheet(
//                "border-image: url(\"/home/armen/Downloads/Images/bg.jpg\") 0 0 0 0 stretch stretch; background-repeat: no-repeat;");
//    ui->stackedWidget->setStyleSheet("background-color: rgb(0, 85, 255, 0);");

}

void MainWindow::ChangeText(QString text)
{
    ui->StatusBar->setText(text);
}

void MainWindow::Delay(int seconds)
{
    QTime dieTime = QTime::currentTime().addSecs(seconds);

    while (QTime::currentTime() < dieTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}

void MainWindow::NFChandle(QString str)
{
    QFile file(str);
    QString line;
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream stream(&file);
        while (!stream.atEnd())
        {
            line.append(stream.readLine() + "\n");
        }

//        ui->nfcdata->setText(line);
    }

    else
        slotError(ERROR_CANNOT_OPEN_TEMP_FILE);

    file.close();

    if(line.length() > 0) myClient->sendNFCEvent(line);
}

void MainWindow::QRhandle(QString str)
{
    QFile file(str);
    QString line;

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream stream(&file);
        while (!stream.atEnd())
        {
            line.append(stream.readLine() + "\n");
        }

//        ui->qrdata->setText(line);
    }

    else
        slotError(ERROR_CANNOT_OPEN_TEMP_FILE);

    file.close();

    if(line.length() > 0) myClient->sendQREvent(line);
}

// #### INITILIZATIONS ####

void MainWindow::InitClient()
{
    connect(myClient, SIGNAL(signalToPrintQr(QString)), this, SLOT(slotPrintQr(QString)));
    connect(myClient, SIGNAL(signalNotEmptySpace()), this, SLOT(slotNotEmptySpace()));
    connect(myClient, SIGNAL(signalWelcome()), this, SLOT(slotWelcome()));
    connect(myClient, SIGNAL(signalUserNotFound()), this, SLOT(slotUserNotFound()));
    connect(myClient, SIGNAL(signalAllFine(QString)), this, SLOT(slotAllFine(QString)));
    connect(myClient, SIGNAL(signalError(int)), this, SLOT(slotError(int)));
}

void MainWindow::InitCPSC()
{
    configSC->setShortcut(Qt::Key_P | Qt::CTRL);
    connect(configSC, SIGNAL(triggered()), this, SLOT(slotCPSC()));

    exitSC->setShortcut(Qt::Key_Q | Qt::CTRL);
    connect(exitSC, SIGNAL(triggered()), this, SLOT(close()));

    returnSC->setShortcut(Qt::Key_Backspace);
    connect(returnSC, &QAction::triggered, this, std::bind(&MainWindow::PageHandler, this, HOMEPAGE));

    this->addAction(configSC);
    this->addAction(exitSC);
    this->addAction(returnSC);
}

void MainWindow::InitSerial()
{
    serial->setPortName(button_serial_port);
    serial->setBaudRate(QSerialPort::Baud9600);
    serial->setDataBits(QSerialPort::Data8);
    serial->setParity(QSerialPort::NoParity);
    serial->setStopBits(QSerialPort::OneStop);
    serial->setFlowControl(QSerialPort::NoFlowControl);
    serial->open(QIODevice::ReadWrite);

    //INIT QR AND NFC SCANNERS SERIALS
    connect(serial, SIGNAL(readyRead()), myClient, SLOT(sendButtonEvent()));
}

// #### SLOTS ####

void MainWindow::slotAllFine(QString str)
{
    QMessageBox::information(this, "Info", str);
}

void MainWindow::slotPrintQr(QString qr)
{
    PageHandler(ONETIMETICKPAGE);
    QRWidget x;
    x.setQRData(qr);
    x.setPath(generatedQRPath);
    x.setFileName("qr.png");
    x.myPaintEvent();
    Delay(3);
    PageHandler(HOMEPAGE);
}

void MainWindow::slotNotEmptySpace()
{
    PageHandler(NOT_FREE_SPACE_PAGE);
    Delay(3);
    PageHandler(HOMEPAGE);
}

void MainWindow::slotUserNotFound()
{
    PageHandler(USERNOTFOUNDPAGE);
    Delay(3);
    PageHandler(HOMEPAGE);
}

void MainWindow::slotWelcome()
{
    PageHandler(WELCOMEPAGE);
    Delay(3);
    PageHandler(HOMEPAGE);
}

void MainWindow::slotError(int ErrorId)
{
    PageHandler(ERROR_PAGE);
    switch(ErrorId)
    {
        case ERROR_CANNOT_CONNECT_SERVER:
            ui->error_lbl->setText("Cannot connect to server");
            break;

        case ERROR_NOT_REGISTERED_ID:
            ui->error_lbl->setText("Terminal is not registered in system");
            break;

        case ERROR_API_READ_GOES_WRONG:
            ui->error_lbl->setText("API READ WENT WRONG!");
            break;

        case ERROR_SOMETHING_WENT_WRONG:
            ui->error_lbl->setText("Something went wrong!");
            break;

        case ERROR_CANNOT_OPEN_TEMP_FILE:
            ui->error_lbl->setText("Cannot open temp file!");
            break;

        default:
            break;
    }

    Delay(3);
    PageHandler(HOMEPAGE);
}

void MainWindow::slotCPSC()
{
    ui->server_ip->setText(myClient->GetServerIp());
    ui->server_port->setText(myClient->GetPort());
    ui->button_serial_port->setText(button_serial_port);
    ui->NFCPath->setText(NFCPath);
    ui->QRPath->setText(QRPath);
    ui->generated_qr_path->setText(generatedQRPath);
    ui->device_id->setText(DeviceId);
    PageHandler(CONFIGPAGE);
}

// #### OTHER ####

void MainWindow::PageHandler(int page)
{
    switch (page)
    {
        case HOMEPAGE:
            ui->stackedWidget->setCurrentWidget(ui->home_page);
            break;

        case CONFIGPAGE:
            ui->stackedWidget->setCurrentWidget(ui->config_page);
            break;

        case WELCOMEPAGE:
            ui->stackedWidget->setCurrentWidget(ui->welcome_page);
            break;

        case USERNOTFOUNDPAGE:
            ui->stackedWidget->setCurrentWidget(ui->user_not_found_page);
            break;

        case ONETIMETICKPAGE:
            ui->stackedWidget->setCurrentWidget(ui->one_time_ticket_page);
            break;

        case NOT_FREE_SPACE_PAGE:
            ui->stackedWidget->setCurrentWidget(ui->not_free_space_page);
            break;

        default:
            ui->stackedWidget->setCurrentWidget(ui->error_page);
            break;

    }
}

// #### CONFIG ####

void MainWindow::LoadConfig()
{    
    if (config->value("Params/magicnum") != MAGICNUM)
    {
        config->setValue("Params/magicnum", MAGICNUM);
        PageHandler(CONFIGPAGE);
        return;
    }

    if (myClient->SetServerIp(config->value("Params/server_ip").toString()) == IP_CHANGE_ERROR || myClient->SetPort(config->value("Params/server_port").toString()) == PORT_CHANGE_ERROR)
    {
        PageHandler(CONFIGPAGE);
        return;
    }

    button_serial_port = config->value("Params/button_serial_port").toString();
    QRPath = config->value("Params/qr_temp_file_path").toString();
    NFCPath = config->value("Params/nfc_temp_file_path").toString();
    generatedQRPath = config->value("Params/generated_qr_path").toString();

    DeviceId = config->value("Params/device_id").toString();

    myClient->setDId(DeviceId);

    if (QFile::exists(QRPath))
    {
        QRwatcher->addPath(QRPath);
        connect(QRwatcher, SIGNAL(fileChanged(QString)), this, SLOT(QRhandle(QString)));
    }
    else
    {
        QMessageBox::warning(this, "Warning!", "Invalid Path for QR!");
    }

    if (QFile::exists(NFCPath))
    {
        NFCwatcher->addPath(NFCPath);
        connect(NFCwatcher, SIGNAL(fileChanged(QString)), this, SLOT(NFChandle(QString)));
    }
    else
    {
        QMessageBox::warning(this, "Warning!", "Invalid Path for NFC!");
        PageHandler(CONFIGPAGE);
    }

    PageHandler(HOMEPAGE);
//    ChangeText(DeviceId + " | " + myClient->GetServerIp() + " | " + myClient->GetPort() + " | " + button_serial_port + " | " + QRPath + " | " + generatedQRPath + " | " + NFCPath);
}


void MainWindow::SaveConfig()
{
    config->setValue("Params/server_port", myClient->GetPort());
    config->setValue("Params/server_ip", myClient->GetServerIp());
    config->setValue("Params/button_serial_port", button_serial_port);
    config->setValue("Params/qr_temp_file_path", QRPath);
    config->setValue("Params/nfc_temp_file_path", NFCPath);
    config->setValue("Params/generated_qr_path", generatedQRPath);
    config->setValue("Params/device_id", DeviceId);
    myClient->setDId(DeviceId);
}

// #### SAVE CONFIG BUTTON ####

void MainWindow::on_pushButton_5_clicked()
{
    if (myClient->SetServerIp(ui->server_ip->text()) == IP_CHANGE_ERROR || ui->button_serial_port->text().length() == 0 || myClient->SetPort(ui->server_port->text()) == PORT_CHANGE_ERROR)
    {
        QMessageBox::warning(this, "Warning!", "Invalid Input!");
        return;
    }

    if (button_serial_port != ui->button_serial_port->text())
    {
        button_serial_port = ui->button_serial_port->text();
        InitSerial();
    }


    if (ui->NFCPath->text() != NFCPath)
    {
        if (QFile::exists(ui->NFCPath->text()))
        {
            NFCPath = ui->NFCPath->text();
            NFCwatcher->addPath(NFCPath);
        }
        else
        {
            QMessageBox::warning(this, "Warning!", "Invalid Path For NFC!");
            return;
        }
    }

    if (ui->QRPath->text() != QRPath)
    {

        if (QFile::exists(ui->QRPath->text()))
        {
            QRPath = ui->QRPath->text();
            QRwatcher->addPath(QRPath);
        }
        else
        {
            QMessageBox::warning(this, "Warning!", "Invalid Path For QR!");
            return;
        }
    }

    if(ui->device_id->text() != DeviceId)
    {
        DeviceId = ui->device_id->text();
        myClient->setDId(DeviceId);
    }

    if (ui->generated_qr_path->text() != generatedQRPath)
    {
        if (QFile::exists(ui->generated_qr_path->text()))
        {
            generatedQRPath = ui->generated_qr_path->text();        }
        else
        {
            QMessageBox::warning(this, "Warning!", "Invalid Path For QT Temp folder!");
            return;
        }
    }

//    ChangeText(DeviceId + " | " + myClient->GetServerIp() + " | " + myClient->GetPort() + " | " + button_serial_port + " | " + QRPath + " | " + generatedQRPath + " | " + NFCPath);

    SaveConfig();

    QMessageBox::information(this, "Info", "Configuration Done!");
    PageHandler(0);
}


MainWindow::~MainWindow()
{
    delete ui;
}

