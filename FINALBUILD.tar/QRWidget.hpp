#ifndef QRWIDGET_HPP
#define QRWIDGET_HPP

#include <QWidget>
#include <QPainter>
#include <QDebug>
#include <qrencode.h>
#include <QBuffer>
#include <QFile>


class QRWidget : public QWidget
{
    Q_OBJECT
private:
    QString data;
    QString path;
    QString filename;

public:
    explicit QRWidget(QWidget *parent = 0);
    void setQRData(QString data);
    void setFileName(QString filename);
    void setPath(QString path);
    //void paintEvent(QPaintEvent *);
    void myPaintEvent();
};

#endif // QRWIDGET_HPP


