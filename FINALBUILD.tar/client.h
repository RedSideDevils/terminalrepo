#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QWidget>
#include <QTcpSocket>
#include <QTextCodec>
#include <QJsonValue>
#include <QJsonValueRef>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include "global.h"

//Error Defines
#define IP_CHANGED 1
#define IP_CHANGE_ERROR 0
#define PORT_CHANGED 1
#define PORT_CHANGE_ERROR 0

//PARAMETERS
#define CONNECT_TIMEOUT 3000

class client : public QObject
{
    Q_OBJECT

public:
    client();
    ~client();

private:
    QHostAddress serverIp;
    QHostAddress tempIp;
    int port;
    QString *msg;
    QString dId;

    bool btn_pressed_flag;
    bool nfc_recieved_flag;
    bool qr_recieved_flag;

protected:
    QString BTN_GET_REQUEST;
    QString QR_GET_REQUEST;
    QString NFC_GET_REQUEST;

public:
    int SetServerIp(QString newIp);
    QString GetServerIp();
    int SetPort(QString newPort);
    QString GetPort();
    void setDId(QString newId);

signals:
    void signalUserNotFound();
    void signalToPrintQr(QString qr);
    void signalNotEmptySpace();
    void signalWelcome();
    void signalAllFine(QString str);
    void signalError(int ErrorId);

public slots:
    void sendButtonEvent();
    void sendQREvent(QString qr);
    void sendNFCEvent(QString nfc);
    void TcpData(int mode);

private:
    QByteArray Data;
    QTcpSocket *socket;
};

#endif // CLIENT_H
