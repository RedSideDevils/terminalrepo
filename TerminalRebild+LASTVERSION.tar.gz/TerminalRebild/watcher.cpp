#include "watcher.h"

Watcher::Watcher(QWidget* pwgt /*=0*/) : QTextEdit(pwgt)
{
    setWindowTitle("Наблюдатель");
}
//выполняем отображение информации при вызовах слотов
void Watcher::slotDirectoryCh( QString& str)
{
    append("Каталог изменен:" + str);
}
void Watcher::slotFileCh( QString& str)
{
    append("Файл изменен:" + str);
}

